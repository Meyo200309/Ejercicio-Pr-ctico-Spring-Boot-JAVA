package com.tuempresa.tuproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
