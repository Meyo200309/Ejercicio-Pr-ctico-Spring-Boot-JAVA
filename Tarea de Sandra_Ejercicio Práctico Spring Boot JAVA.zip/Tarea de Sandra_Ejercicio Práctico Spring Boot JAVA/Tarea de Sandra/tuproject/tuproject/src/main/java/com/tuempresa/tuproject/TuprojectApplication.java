package com.tuempresa.tuproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TuprojectApplication.class, args);
	}

}
